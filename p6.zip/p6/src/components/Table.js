import React from 'react'

function Table(props) {

    let telMarks = Number(props.telMarks);
    let HinMarks = Number(props.hinMarks);
    let engMarks = Number(props.engMarks);
    let MatMarks = Number(props.matMarks);
    let sciMarks = Number(props.sciMarks);
    let socMarks = Number(props.socMarks);
    let total = telMarks+HinMarks+engMarks+MatMarks+sciMarks+socMarks;
    let perc = (total/600)*100;
    


  return (
    <div>
    <table>
    <thead>
    <tr>
    <th>S.No</th>
    <th>Subject</th>
    <th>Max.Marks</th>
    <th>Marks Obtained</th>
    <th>Result</th>
    </tr>
    </thead>
    <tbody>
    <tr>
    <td>1</td>
    <td>Telugu</td>
    <td>100</td>
    <td>{telMarks}</td>
    <td>Pass</td>
    </tr>
    <tr>
    <td>2</td>
    <td>Hindi</td>
    <td>100</td>
    <td>{HinMarks}</td>
    <td>Pass</td>
    </tr>
    <tr>
    <td>3</td>
    <td>English</td>
    <td>100</td>
    <td>{engMarks}</td>
    <td>Pass</td>
    </tr>
    <tr>
    <td>4</td>
    <td>Maths</td>
    <td>100</td>
    <td>{MatMarks >= 35?"Pass":"Fail"}</td>
    <td>Pass</td>
    </tr>
    <tr>
    <td>5</td>
    <td>Science</td>
    <td>100</td>
    <td>{sciMarks >= 35?"Pass" :"Fail"}</td>
    <td>Pass</td>
    </tr>
    <tr>
    <td>6</td>
    <td>Social</td>
    <td>100</td>
    <td>{socMarks}</td>
    <td>{socMarks >=35?"Pass" :"Fail"}</td>
    </tr>
    </tbody>
    <tfoot>
    <tr>
    <th>7</th>
    <th>Total</th>
    <th>600</th>
    <th>{total}({perc.toFixed(2)}%)</th>
    <th>Distinction Pass</th>
    </tr>
    </tfoot>
    </table>
    </div>

  )
}

export default Table