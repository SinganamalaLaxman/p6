import logo from './logo.svg';
import './App.css';
import Table from "./components/Table";

function App() {
  return (
    <div className="App">
      <Table telMarks = "75" hinMarks = "95"engMarks = "85" matMarks = "83" sciMarks = "95" socMarks = "73" ></Table>
      <Table telMarks = "67" hinMarks = "75" engMarks = "92" matMarks = "97" sciMarks = "88" socMarks = "95"></Table>
      <Table telMarks = "78" hinMarks = "85"engMarks = "85" matMarks = "83" sciMarks = "95" socMarks = "73" ></Table>
      <Table telMarks = "65" hinMarks = "95" engMarks = "92" matMarks = "97" sciMarks = "88" socMarks = "95"></Table>
      <Table telMarks = "78" hinMarks = "85"engMarks = "85" matMarks = "83" sciMarks = "95" socMarks = "73" ></Table>
      <Table telMarks = "87" hinMarks = "65" engMarks = "92" matMarks = "97" sciMarks = "88" socMarks = "95"></Table>
      <Table telMarks = "95" hinMarks = "75"engMarks = "85" matMarks = "83" sciMarks = "95" socMarks = "73" ></Table>
      <Table telMarks = "87" hinMarks = "88" engMarks = "92" matMarks = "97" sciMarks = "88" socMarks = "95"></Table>
    </div>
  );
}

export default App;
